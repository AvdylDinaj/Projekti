
import java.awt.*;
public class DistanceFromSun {

	public static void main(String[] args) {
		BarGraphWriter d=new BarGraphWriter();
		d.setTitle("Distance e planeteve te nga Dielli ");
		d.setAxes(20, 120, "10", 100);
		int scale_factor=1;
		d.setBar1("Merkur", 4*scale_factor, Color.red);
		d.setBar2("Venera",7*scale_factor,Color.yellow);
		d.setBar3("Toka", 10*scale_factor, Color.pink);
		d.setBar4("Mars", 15*scale_factor, Color.black);
		d.setBar5("Jupiter", 52*scale_factor, Color.gray);
		d.setBar6("Saturn",95*scale_factor,Color.blue);





	}

}
