
	import java.awt.*;
	public class TestBarGraphWriter {

		public static void main(String[] args) {
			
		    BarGraphWriter e = new BarGraphWriter();
			e.setTitle("6 muajte e pare te vitit");
			e.setAxes(20, 120, "30", 90);
			int scale_factor=3;
			e.setBar1("Janar", 31*scale_factor, Color.red);
			e.setBar2("Shkurt", 28*scale_factor,Color.yellow);
			e.setBar3("Mars", 31*scale_factor, Color.pink);
			e.setBar4("Prill", 30*scale_factor, Color.black);
			e.setBar5("Maj", 31*scale_factor, Color.gray);
			e.setBar6("Qershor", 30*scale_factor,Color.blue);
			}
			
		}
